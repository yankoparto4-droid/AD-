@echo off
rem Revert changes made by this kit
rem Double-click this file. A UAC prompt will appear; click Yes.
title Revert AD Speedup
echo.
echo  Reverting exclusions and power plan...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ad-speedup-revert.ps1"
if errorlevel 1 pause
