@echo off
rem Altium Designer speedup - portable kit
rem Double-click this file. A UAC prompt will appear; click Yes.
title AD Speedup
echo.
echo  Scanning for Altium Designer and preparing exclusions...
echo  A UAC prompt will appear. Please click "Yes".
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ad-speedup.ps1" %*
if errorlevel 1 pause
