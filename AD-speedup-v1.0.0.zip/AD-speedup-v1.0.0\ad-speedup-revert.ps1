﻿#Requires -Version 5.1
<#
    撤销脚本：读取本工具生成的 applied-*.txt，把当初加的排除项全部移除，
    并把电源计划切回原来的方案。
#>
$ErrorActionPreference = 'Continue'

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host '需要管理员权限，正在请求提权...' -ForegroundColor Yellow
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    return
}

$kitDir = $PSScriptRoot
if (-not $kitDir) { $kitDir = (Get-Location).Path }

$manifests = @(Get-ChildItem $kitDir -Filter 'applied-*.txt' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
if ($manifests.Count -eq 0) {
    $alt = Join-Path $env:TEMP 'ad-speedup'
    $manifests = @(Get-ChildItem $alt -Filter 'applied-*.txt' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
}
if ($manifests.Count -eq 0) {
    Write-Host '没有找到 applied-*.txt 改动清单，无法自动撤销。' -ForegroundColor Yellow
    Write-Host '可以手动到「Windows 安全中心 → 病毒和威胁防护 → 管理设置 → 排除项」里删除。' -ForegroundColor Gray
    Read-Host '按回车关闭' | Out-Null
    return
}

Write-Host ''
Write-Host '找到以下改动记录：' -ForegroundColor Cyan
for ($i = 0; $i -lt $manifests.Count; $i++) {
    Write-Host ("  [{0}] {1}  ({2})" -f ($i+1), $manifests[$i].Name, $manifests[$i].LastWriteTime)
}
$pick = Read-Host "要撤销哪一次？输入编号（回车=最近一次）"
$idx = 0
if ($pick -match '^\d+$') { $idx = [int]$pick - 1 }
if ($idx -lt 0 -or $idx -ge $manifests.Count) { $idx = 0 }

$file = $manifests[$idx]
$items = Get-Content $file.FullName -Encoding UTF8

Write-Host ''
Write-Host "正在按 $($file.Name) 撤销..." -ForegroundColor Cyan

foreach ($line in $items) {
    if ($line -match '^EXCLUDE_PATH=(.+)$') {
        $p = $Matches[1]
        try { Remove-MpPreference -ExclusionPath $p -ErrorAction Stop; Write-Host "  ✓ 已移除: $p" -ForegroundColor Green }
        catch { Write-Host "  - 跳过: $p" -ForegroundColor DarkGray }
    }
    elseif ($line -match '^EXCLUDE_PROC=(.+)$') {
        $p = $Matches[1]
        try { Remove-MpPreference -ExclusionProcess $p -ErrorAction Stop; Write-Host "  ✓ 已移除进程: $p" -ForegroundColor Green }
        catch { Write-Host "  - 跳过: $p" -ForegroundColor DarkGray }
    }
    elseif ($line -match '^POWERPLAN_PREV=(.+)$') {
        $g = $Matches[1]
        powercfg /setactive $g | Out-Null
        Write-Host "  ✓ 电源计划已恢复: $g" -ForegroundColor Green
    }
}

Rename-Item $file.FullName ($file.BaseName + '.reverted.txt') -ErrorAction SilentlyContinue
Write-Host ''
Write-Host '完成。' -ForegroundColor Cyan
Read-Host '按回车关闭' | Out-Null
