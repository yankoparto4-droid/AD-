﻿#Requires -Version 5.1
<#
    Altium Designer 加速工具（通用版）
    ============================================================
    作用：
      1) 自动寻找本机 Altium Designer 安装目录
      2) 把它和相关数据目录加入 Windows Defender 排除项
         （这样 Defender 不再逐个扫描 AD 的几千个文件）
      3) 可选：结束正在进行的 Defender 扫描 / 电源计划切高性能

    用法：
      双击 run-ad-speedup.bat          （推荐）
      或：powershell -ExecutionPolicy Bypass -File ad-speedup.ps1
      只看不改：加 -DryRun
      追加目录：-ExtraPaths "E:\MyProjects","D:\Work\PCB"

    撤销：run-ad-speedup-revert.bat（或 ad-speedup-revert.ps1）
#>
[CmdletBinding()]
param(
    [string[]]$ExtraPaths = @(),
    [switch]$StopScan,
    [switch]$NoPowerPlan,
    [switch]$DryRun,
    [switch]$Yes
)

$ErrorActionPreference = 'Continue'

# ---------- 0. 提权 ----------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and -not $DryRun) {
    Write-Host '需要管理员权限，正在请求提权（弹出 UAC 请点“是”）...' -ForegroundColor Yellow
    $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($StopScan)  { $a += '-StopScan' }
    if ($NoPowerPlan) { $a += '-NoPowerPlan' }
    if ($Yes) { $a += '-Yes' }
    foreach ($p in $ExtraPaths) { $a += @('-ExtraPaths', "`"$p`"") }
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $a
    return
}

# ---------- 1. 基础 ----------
$kitDir = $PSScriptRoot
if (-not $kitDir) { $kitDir = (Get-Location).Path }
# 便携盘可能只读，写不了就退回临时目录
try {
    $probe = Join-Path $kitDir ".write-test"
    Set-Content -Path $probe -Value 'ok' -ErrorAction Stop
    Remove-Item $probe -Force -ErrorAction SilentlyContinue
} catch {
    $kitDir = Join-Path $env:TEMP 'ad-speedup'
    New-Item -ItemType Directory -Path $kitDir -Force | Out-Null
}
$stamp    = Get-Date -Format 'yyyyMMdd-HHmmss'
$manifest = Join-Path $kitDir "applied-$stamp.txt"

function Write-Step { param($t) Write-Host "`n=== $t ===" -ForegroundColor Cyan }

Write-Host ''
Write-Host '  Altium Designer 加速工具' -ForegroundColor White
Write-Host '  -------------------------' -ForegroundColor DarkGray
Write-Host ("  计算机: {0}   用户: {1}" -f $env:COMPUTERNAME, $env:USERNAME) -ForegroundColor DarkGray

# ---------- 2. 自动查找 Altium ----------
Write-Step '查找 Altium Designer'

function Find-AltiumInstall {
    $found = New-Object System.Collections.Generic.List[string]

    # 2.1 卸载注册表
    $unroots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($r in $unroots) {
        Get-ItemProperty $r -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -match 'Altium' } |
            ForEach-Object {
                if ($_.InstallLocation -and (Test-Path (Join-Path $_.InstallLocation 'X2.EXE'))) {
                    $found.Add($_.InstallLocation)
                } elseif ($_.DisplayIcon) {
                    $ic = $_.DisplayIcon.Trim('"').Split(',')[0]
                    if (Test-Path $ic) { $found.Add((Split-Path $ic -Parent)) }
                }
            }
    }

    # 2.2 常见默认位置
    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $base) { continue }
        $d = Join-Path $base 'Altium'
        if (Test-Path $d) {
            Get-ChildItem $d -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                if (Test-Path (Join-Path $_.FullName 'X2.EXE')) { $found.Add($_.FullName) }
            }
        }
    }

    # 2.3 所有固定盘：先看名字像不像，再看两级
    $drives = Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue |
              Where-Object { $_.Root -match '^[A-Za-z]:\\$' } |
              ForEach-Object { $_.Root }
    foreach ($d in $drives) {
        $lvl1 = Get-ChildItem $d -Directory -ErrorAction SilentlyContinue
        foreach ($x in $lvl1) {
            if (Test-Path (Join-Path $x.FullName 'X2.EXE')) { $found.Add($x.FullName); continue }
            if ($x.Name -notmatch 'altium|pcb|^ad\d*$') { continue }   # 名字不像的先跳过
            Get-ChildItem $x.FullName -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                if (Test-Path (Join-Path $_.FullName 'X2.EXE')) { $found.Add($_.FullName) }
            }
        }
    }

    return $found | Sort-Object -Unique
}

$altiumDirs = @(Find-AltiumInstall)

if ($altiumDirs.Count -eq 0) {
    Write-Host '  ⚠ 没有自动找到 Altium Designer。' -ForegroundColor Yellow
    if (-not $Yes -and -not $DryRun) {
        $manual = Read-Host '  可以手动输入 Altium 安装目录（含 X2.EXE），直接回车跳过'
        if ($manual -and (Test-Path (Join-Path $manual.Trim('"') 'X2.EXE'))) { $altiumDirs = @($manual.Trim('"')) }
    }
} else {
    foreach ($d in $altiumDirs) { Write-Host "  ✓ 找到: $d" -ForegroundColor Green }
}

# ---------- 3. 组装排除列表 ----------
Write-Step '生成排除列表'

$targets = New-Object System.Collections.Generic.List[string]

foreach ($d in $altiumDirs) {
    $targets.Add($d)                                        # 安装目录本体
    $parent = Split-Path $d -Parent
    # 父目录不是盘根、也不是 Program Files，就当工作区一起排除（比如 D:\Work）
    if ($parent -and $parent -notmatch '^[A-Za-z]:\\$' -and
        $parent -notmatch 'Program Files') {
        $targets.Add($parent)
    }
}

foreach ($d in @('C:\ProgramData\Altium',
                 (Join-Path $env:LOCALAPPDATA 'Altium'),
                 (Join-Path $env:APPDATA      'Altium'))) {
    if (Test-Path $d) { $targets.Add($d) }
}

foreach ($p in $ExtraPaths) { if (Test-Path $p) { $targets.Add($p) } }

# 手动再补一段（不自动确认时）
if (-not $Yes -and -not $DryRun) {
    Write-Host ''
    Write-Host '  除了上面这些，还想排除别的目录吗？（比如工程文件夹）' -ForegroundColor Gray
    $more = Read-Host '  输入完整路径，多个用英文逗号隔开；直接回车跳过'
    if ($more) {
        foreach ($p in ($more -split ',')) {
            $p = $p.Trim().Trim('"')
            if ($p -and (Test-Path $p)) { $targets.Add($p) }
            elseif ($p) { Write-Host "  跳过（不存在）: $p" -ForegroundColor DarkGray }
        }
    }
}

$targets = @($targets | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique)

Write-Host ''
if ($targets.Count -eq 0) {
    Write-Host '  没有可排除的目录，脚本结束。' -ForegroundColor Yellow
    if (-not $Yes) { Read-Host '按回车关闭' }
    return
}
foreach ($t in $targets) { Write-Host "  → $t" }
Write-Host '  → X2.EXE（进程）'

if ($DryRun) {
    Write-Host ''
    Write-Host '  [DryRun] 只看不改，脚本结束。去掉 -DryRun 才会真正写入。' -ForegroundColor Cyan
    return
}

if (-not $Yes) {
    Write-Host ''
    $ok = Read-Host '  确认写入这些排除项？[Y/n]'
    if ($ok -and $ok -notmatch '^[Yy]') { Write-Host '  已取消。' -ForegroundColor Yellow; return }
}

# ---------- 4. 检测并结束扫描 ----------
Write-Step '检查 Defender 扫描'

$scanProc = Get-Process -Name MpCmdRun -ErrorAction SilentlyContinue
if ($scanProc) {
    $cpuNow = 0
    try { $cpuNow = (Get-Counter '\Process(msmpeng)\% Processor Time' -SampleInterval 1 -MaxSamples 1).CounterSamples[0].CookedValue } catch { }
    Write-Host ("  检测到全盘/按需扫描正在跑：MpCmdRun PID {0}，占用约 {1:N0}%" -f $scanProc.Id, $cpuNow) -ForegroundColor Yellow
    $ans = 'Y'
    if (-not $StopScan -and -not $Yes) { $ans = Read-Host '  是否现在结束这次扫描？[Y/n]' }
    if ($ans -eq '' -or $ans -match '^[Yy]') {
        $scanProc | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host '  已结束扫描，等待 15 秒...' -ForegroundColor Green
        Start-Sleep -Seconds 15
        try { Write-Host ("  当前总 CPU: {0:N0}%" -f (Get-Counter '\Processor Information(_Total)\% Processor Time').CounterSamples[0].CookedValue) -ForegroundColor Green } catch { }
    }
} else {
    Write-Host '  当前没有扫描在跑。' -ForegroundColor Green
}

# ---------- 5. 写入排除项 ----------
Write-Step '写入 Defender 排除项'

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("HOST=$env:COMPUTERNAME")
$lines.Add("TIME=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")

foreach ($t in $targets) {
    try {
        Add-MpPreference -ExclusionPath $t -ErrorAction Stop
        Write-Host "  ✓ 已排除目录: $t" -ForegroundColor Green
        $lines.Add("EXCLUDE_PATH=$t")
    } catch {
        Write-Host "  ✗ 失败: $t  ->  $($_.Exception.Message)" -ForegroundColor Red
    }
}

try {
    Add-MpPreference -ExclusionProcess 'X2.EXE' -ErrorAction Stop
    Write-Host '  ✓ 已排除进程: X2.EXE' -ForegroundColor Green
    $lines.Add('EXCLUDE_PROC=X2.EXE')
} catch {
    Write-Host "  ✗ 进程排除失败: $($_.Exception.Message)" -ForegroundColor Red
}

# ---------- 6. 电源计划 ----------
if (-not $NoPowerPlan) {
    Write-Step '电源计划 -> 高性能'
    try {
        $cur = (powercfg /getactivescheme) -join ' '
        $guid = '381b4222-f694-41f0-9685-ff5bb260df2e'
        if ($cur -match '([0-9a-fA-F-]{36})') { $guid = $Matches[1] }
        $lines.Add("POWERPLAN_PREV=$guid")
        powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c | Out-Null
        Write-Host '  ✓ 已切换到高性能' -ForegroundColor Green
    } catch {
        Write-Host "  切换失败（不影响其他改动）" -ForegroundColor Yellow
    }
}

# ---------- 7. 记录清单 ----------
$lines | Set-Content -Path $manifest -Encoding UTF8
Write-Host ''
Write-Host "  本次改动清单已保存：$manifest" -ForegroundColor DarkGray
Write-Host '  以后想撤销，双击 run-ad-speedup-revert.bat 即可。' -ForegroundColor DarkGray

# ---------- 8. 结果 ----------
Write-Step '当前排除项'
try {
    $after = (Get-MpPreference).ExclusionPath
    if ($after) { $after | ForEach-Object { Write-Host "    $_" } } else { Write-Host '    （空）' }
} catch { }

Write-Host ''
Write-Host '  完成。现在打开 Altium Designer 试试启动速度。' -ForegroundColor Cyan
if (-not $Yes) { Read-Host '按回车关闭' | Out-Null }
