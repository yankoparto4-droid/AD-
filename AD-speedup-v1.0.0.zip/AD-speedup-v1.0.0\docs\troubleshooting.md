# 排查：AD 启动慢到底是卡在哪

不要凭感觉，用数据。下面是这台机器上实际跑过的命令，你可以照抄。

## 第一步：看 CPU 是不是真的被占满了

```powershell
# 总占用
Get-Counter '\Processor Information(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 3

# 空闲率（低于 10 基本就是满载）
Get-Counter '\Processor Information(_Total)\% Idle Time'
```

## 第二步：找出是谁在吃 CPU

`Get-Process` 的 `TotalProcessorTime` 在部分系统上读不到，用性能计数器更可靠：

```powershell
(Get-Counter '\Process(*)\% Processor Time' -SampleInterval 2 -MaxSamples 1).CounterSamples |
    Where-Object { $_.InstanceName -notmatch '^(_total|idle)$' -and $_.CookedValue -gt 20 } |
    Sort-Object CookedValue -Descending |
    Format-Table InstanceName, CookedValue -AutoSize
```

输出若长这样：

```
InstanceName   CookedValue
msmpeng            1488.0
system               46.0
```

那就跟 AD 没关系了——`msmpeng` 是 Windows Defender 的扫描引擎。

## 第三步：确认是不是"全盘扫描"在跑

```powershell
Get-Process MpCmdRun -ErrorAction SilentlyContinue
```

有 `MpCmdRun` 在跑，说明是一次**按需/全盘扫描**（定时快速扫描也会用它，但通常几分钟结束）。

再看事件日志，能拿到开始时间和持续时长：

```powershell
Get-WinEvent -FilterHashtable @{
    LogName = 'Microsoft-Windows-Windows Defender/Operational'
    Id = 1000,1001
} -MaxEvents 10 | Select-Object TimeCreated, Id, @{n='Msg';e={($_.Message -split "`n")[0]}}
```

- `1000` = 扫描开始
- `1001` = 扫描结束

**只有 1000 没有对应的 1001，就是还在扫。**

## 第四步：看它在读什么

```powershell
Get-Counter '\Process(msmpeng)\IO Read Bytes/sec' -SampleInterval 2
```

十几 MB/s 加上几千次 IO/秒，就是逐文件扫盘的典型特征。

扫多久可以粗略估：**已用空间 ÷ 15~20 MB/s**。1000GB 的机器扫上一两个小时很正常。

## 第五步：确认 AD 的负载长什么样

把 AD 单独跑起来（Defender 排除项加好之后），观察：

```powershell
(Get-Counter '\Process(x2)\% Processor Time' -SampleInterval 2).CounterSamples[0].CookedValue
```

- AD 只吃 20–30% → 瓶颈不在 CPU，多半是磁盘或工程本身太大
- AD 长期 80% 以上 → 这才是真的算力瓶颈，才值得考虑升级 CPU

## 结论模板

| 现象 | 结论 |
|---|---|
| `msmpeng` 高，AD 接近 0 | 杀软问题，加排除项，别换硬件 |
| `msmpeng` 高且 `MpCmdRun` 在跑 | 全盘扫描，结束它 + 加排除项 |
| AD 自身高但 CPU 频率只有 2.5GHz | 降频（散热/供电），不是 CPU 不行 |
| AD 自身高且频率正常 | 工程太大或单核瓶颈，考虑升级 |
