# Changelog

本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [1.0.0] - 2026-11-17

首个公开版本。

### 新增

- 自动定位 Altium Designer 安装目录（注册表卸载项 → 默认路径 → 全盘两级扫描）
- 一键把 AD 安装目录、父目录、`ProgramData\Altium`、用户 AppData 加入 Defender 排除项
- 检测并结束正在运行的 Defender 全盘扫描（这是 AD "启动卡死"的常见元凶）
- 电源计划切换为高性能（可 `-NoPowerPlan` 关闭）
- 每次改动生成 `applied-<时间戳>.txt` 记录，支持一键撤销
- `-DryRun` 只预览不修改
- `-ExtraPaths` 追加自定义工程目录
- 便携设计：整个目录可放 U 盘，只读介质会自动退到临时目录写记录
