# AD-Speedup · Altium Designer 启动加速

> 一个 Windows 小工具：把 Altium Designer 从"开一次等三分钟"变成"十几秒进界面"。
> 原理很朴素——**AD 慢，通常不是电脑不行，是杀毒软件在逐个扫描它的几千个文件。**

![PowerShell](https://img.shields.io/badge/PowerShell-5.1%2B-blue)
![Platform](https://img.shields.io/badge/Windows-10%20%7C%2011-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 问题是什么

Altium Designer 24 的安装目录有 **5000 多个文件**（`simbeor_sdk.dll` 109MB、`X2.EXE` 40MB）；
再加上 `C:\ProgramData\Altium` 里 2000 多个共享数据文件。

Windows Defender 的**实时保护**会在 AD 打开每一个文件时先扫一遍。几千次扫描叠加起来，
就是你感受到的"卡在启动界面几十秒到几分钟"。

更糟的情况是 Defender 正在跑**全盘扫描**。实测某台机器：

```
MsMpEng（Defender 引擎）  CPU 占用 1488%   16 个逻辑核，空闲 0.1%
AD 本身                    CPU 占用 接近 0
```

这时候你把 AD 关掉、重装、换电脑都没用——**扫的是整块硬盘，不是 AD。**

## 它做什么

| 动作 | 说明 |
|---|---|
| 🔍 自动找 AD | 注册表卸载项 → 默认路径 → 全盘两级扫 `X2.EXE`，找不到会问你 |
| 🛡️ 加白名单 | 把 AD 安装目录 / 父目录 / `ProgramData` / 用户 AppData 加入 Defender 排除项 |
| ⚡ 结束卡死扫描 | 检测到 `MpCmdRun` 在跑时，问你要不要结束 |
| 🔋 高性能电源 | 避免 CPU 低频拖慢启动（可关） |
| 📝 可撤销 | 每次改动写 `applied-*.txt`，一键还原 |

**不会关闭 Defender**，只加白名单；**不会排除整个磁盘**，只排 AD 相关目录。

## 快速开始

1. 下载仓库（或 [Releases](../../releases) 里的 zip），解压到任意位置
2. 双击 **`run-ad-speedup.bat`**
3. UAC 弹窗点「是」
4. 确认脚本列出的路径 → 回车
5. 打开 Altium Designer

换新电脑时建议先看一眼它会改什么：

```bat
run-ad-speedup.bat -DryRun
```

撤销：

```bat
run-ad-speedup-revert.bat
```

## 命令行参数

| 参数 | 作用 |
|---|---|
| `-DryRun` | 只检测、只打印，不修改任何东西 |
| `-ExtraPaths "E:\A","D:\B"` | 额外排除的目录（工程文件夹等） |
| `-StopScan` | 自动结束正在跑的 Defender 扫描，不再询问 |
| `-NoPowerPlan` | 不修改电源计划 |
| `-Yes` | 全程不提问（适合批量部署） |

也可以直接调 PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File ad-speedup.ps1 -DryRun
```

## 它会排除哪些路径

```
<AD 安装目录>                         例：D:\PCB\AD24
<AD 安装目录的父目录>                  例：D:\PCB        （通常存工程和库）
C:\ProgramData\Altium
%LOCALAPPDATA%\Altium
%APPDATA%\Altium
X2.EXE（进程级）
```

父目录如果是**盘根**或 `Program Files` 下属，会自动跳过，避免误伤。

## 安全性

- 只加白名单，不关闭实时保护
- 排除范围限于 AD 相关目录，不排除整个磁盘
- 所有改动都有记录文件，可完整撤销

⚠️ 排除项意味着这些目录里的文件不再被实时扫描。如果你的工程目录里经常出现
来路不明的文件（比如从网上下载的"破解库""绿色版插件"），请自行权衡——
可以只用 `-ExtraPaths` 精确指定某个工程文件夹，而不是整个盘。

## 常见问题

**Q：我装了 360 / 火绒 / 卡巴斯基，还有用吗？**
没用。第三方杀软会接管实时保护，Defender 自动让位。需要去那家杀软里加白名单，
路径就是脚本列出来的那几个。

**Q：跑完还是慢？**
看 [docs/troubleshooting.md](docs/troubleshooting.md)，用性能计数器确认到底是谁在吃 CPU。

**Q：会不会影响系统更新或安全更新？**
不会。排除项只作用于指定目录。

**Q：支持 AD 的哪些版本？**
不挑版本，靠 `X2.EXE` 识别。AD 19 到 AD 25 都适用。

**Q：为什么用 PowerShell 而不是 exe？**
脚本可读、可审计，你可以先 `-DryRun` 看完再决定要不要跑。

## 已知限制

- 仅 Windows 10 / 11 + Windows PowerShell 5.1（系统自带，无需安装）
- AD 被改名或装在非常规位置时需要手动输入路径
- 只处理 Defender；第三方杀软需自行配置
- 不同版本 AD 的文件规模不同，加速幅度不保证

## 目录结构

```
ad-speedup/
├── ad-speedup.ps1              主脚本
├── ad-speedup-revert.ps1       撤销脚本
├── run-ad-speedup.bat          双击入口
├── run-ad-speedup-revert.bat   撤销入口
├── docs/troubleshooting.md     排查方法
├── CHANGELOG.md
└── LICENSE
```

## 贡献

欢迎提 Issue 说清楚：
- Windows 版本、AD 版本、是否装了第三方杀毒
- `-DryRun` 的输出
- 改前 / 改后的启动耗时

## 许可证

[MIT](LICENSE)
